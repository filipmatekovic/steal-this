# Inbound Weekly

Companion to: *How I replaced a manual Monday inbound report with an automated Slack post*

Files:
- `spec.txt`: definitions, sources, output shape, rules. Write your own definitions first, do not skip that part.
- `prompt.txt`: scheduled task prompt. Swap tool names and channel for yours.

How I run it: Claude scheduled task, Monday morning, cloud. HubSpot, GA4 and Slack connect directly. Google Ads, Meta, LinkedIn and Reddit go through Make scenarios that expose weekly numbers as a tool. Test runs go to my DM, production to the marketing channel.
